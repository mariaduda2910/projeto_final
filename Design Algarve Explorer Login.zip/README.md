
  # Design Algarve Explorer Login

  This is a code bundle for Design Algarve Explorer Login. The original project is available at https://www.figma.com/design/DypYkqgQRoXbM4I5Vhv8xR/Design-Algarve-Explorer-Login.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  