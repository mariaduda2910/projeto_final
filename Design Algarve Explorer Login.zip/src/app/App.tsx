import { useState } from 'react';
import { motion } from 'motion/react';
import { RegisterModal } from './components/RegisterModal';

export default function App() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Login attempt:', { email, password });
  };

  return (
    <div className="size-full flex items-center justify-center bg-white relative overflow-hidden">
      {/* Ambient background elements */}
      <div className="absolute inset-0 opacity-[0.03]">
        <div className="absolute top-0 right-0 w-[800px] h-[800px] rounded-full bg-[#0066CC] blur-[120px] translate-x-1/2 -translate-y-1/2" />
        <div className="absolute bottom-0 left-0 w-[600px] h-[600px] rounded-full bg-[#0066CC] blur-[100px] -translate-x-1/2 translate-y-1/2" />
      </div>

      {/* Main login card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.19, 1, 0.22, 1] }}
        className="relative z-10 w-full max-w-[440px] px-6"
      >
        {/* Wave icon */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2, ease: [0.19, 1, 0.22, 1] }}
          className="flex justify-center mb-12"
        >
          <div className="relative">
            <svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
              <motion.circle
                cx="40"
                cy="40"
                r="38"
                stroke="url(#waveGradient)"
                strokeWidth="2"
                fill="none"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 1.5, delay: 0.3, ease: "easeInOut" }}
              />
              <defs>
                <linearGradient id="waveGradient" x1="0" y1="0" x2="80" y2="80" gradientUnits="userSpaceOnUse">
                  <stop offset="0%" stopColor="#0066CC" />
                  <stop offset="100%" stopColor="#0099FF" />
                </linearGradient>
              </defs>
              <motion.path
                d="M25 35 Q30 30, 35 35 T45 35 Q50 30, 55 35"
                stroke="#0066CC"
                strokeWidth="2.5"
                fill="none"
                strokeLinecap="round"
                animate={{
                  d: [
                    "M25 35 Q30 30, 35 35 T45 35 Q50 30, 55 35",
                    "M25 35 Q30 40, 35 35 T45 35 Q50 40, 55 35",
                    "M25 35 Q30 30, 35 35 T45 35 Q50 30, 55 35",
                  ],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
              />
              <motion.path
                d="M25 45 Q30 40, 35 45 T45 45 Q50 40, 55 45"
                stroke="#0099FF"
                strokeWidth="2"
                fill="none"
                strokeLinecap="round"
                opacity="0.6"
                animate={{
                  d: [
                    "M25 45 Q30 40, 35 45 T45 45 Q50 40, 55 45",
                    "M25 45 Q30 50, 35 45 T45 45 Q50 50, 55 45",
                    "M25 45 Q30 40, 35 45 T45 45 Q50 40, 55 45",
                  ],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "easeInOut",
                  delay: 0.5,
                }}
              />
            </svg>
          </div>
        </motion.div>

        {/* App title */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl mb-2 tracking-tight" style={{ color: '#0066CC' }}>
            Algarve Explorer
          </h1>
          <p className="text-gray-500 text-sm tracking-wide">Descubra o paraíso costeiro</p>
        </motion.div>

        {/* Login form */}
        <motion.form
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          onSubmit={handleSubmit}
          className="space-y-6"
        >
          {/* Email field */}
          <div className="relative">
            <label htmlFor="email" className="block text-sm mb-2 text-gray-700">
              Email
            </label>
            <div className="relative">
              <input
                type="email"
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                onFocus={() => setFocusedField('email')}
                onBlur={() => setFocusedField(null)}
                className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl outline-none transition-all duration-300 bg-white"
                style={{
                  borderColor: focusedField === 'email' ? '#0066CC' : undefined,
                  boxShadow: focusedField === 'email' ? '0 0 0 4px rgba(0, 102, 204, 0.08)' : undefined,
                }}
                placeholder="seu@email.com"
                required
              />
            </div>
          </div>

          {/* Password field */}
          <div className="relative">
            <label htmlFor="password" className="block text-sm mb-2 text-gray-700">
              Palavra-passe
            </label>
            <div className="relative">
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onFocus={() => setFocusedField('password')}
                onBlur={() => setFocusedField(null)}
                className="w-full px-4 py-3.5 border-2 border-gray-200 rounded-xl outline-none transition-all duration-300 bg-white"
                style={{
                  borderColor: focusedField === 'password' ? '#0066CC' : undefined,
                  boxShadow: focusedField === 'password' ? '0 0 0 4px rgba(0, 102, 204, 0.08)' : undefined,
                }}
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          {/* Submit button */}
          <motion.button
            type="submit"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="w-full py-4 rounded-xl text-white font-medium text-lg tracking-wide transition-all duration-300 shadow-lg relative overflow-hidden group"
            style={{
              background: 'linear-gradient(135deg, #0066CC 0%, #0052A3 100%)',
              boxShadow: '0 10px 30px -10px rgba(0, 102, 204, 0.4)',
            }}
          >
            <span className="relative z-10">Entrar</span>
            <motion.div
              className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity duration-300"
            />
          </motion.button>

          {/* Forgot password link */}
          <div className="text-center pt-2">
            <motion.a
              href="#"
              whileHover={{ x: 2 }}
              className="text-sm text-gray-600 hover:text-[#0066CC] transition-colors duration-300 inline-block"
              onClick={(e) => {
                e.preventDefault();
                console.log('Forgot password clicked');
              }}
            >
              Esqueci-me da palavra-passe
            </motion.a>
          </div>
        </motion.form>

        {/* Register link */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="text-center mt-8"
        >
          <p className="text-sm text-gray-600">
            Ainda não tem conta?{' '}
            <motion.button
              whileHover={{ x: 2 }}
              onClick={() => setIsRegisterModalOpen(true)}
              className="text-[#0066CC] font-medium hover:underline transition-all duration-300 inline-block"
            >
              Criar conta
            </motion.button>
          </p>
        </motion.div>

        {/* Decorative element */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="mt-8 flex justify-center"
        >
          <div className="flex gap-1.5">
            {[...Array(3)].map((_, i) => (
              <motion.div
                key={i}
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.3, 0.6, 0.3],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: i * 0.3,
                }}
                className="w-1.5 h-1.5 rounded-full"
                style={{ backgroundColor: '#0066CC' }}
              />
            ))}
          </div>
        </motion.div>
      </motion.div>

      {/* Register Modal */}
      <RegisterModal
        isOpen={isRegisterModalOpen}
        onClose={() => setIsRegisterModalOpen(false)}
      />
    </div>
  );
}