import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';
import { Github } from 'lucide-react';

interface RegisterModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function RegisterModal({ isOpen, onClose }: RegisterModalProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [focusedField, setFocusedField] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      alert('As palavras-passe não coincidem');
      return;
    }
    console.log('Register with email:', { email, password });
    onClose();
  };

  const handleGithubLogin = () => {
    console.log('Login with GitHub');
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50"
            onClick={onClose}
          />

          {/* Modal */}
          <div className="fixed inset-0 flex items-center justify-center z-50 p-6 pointer-events-none">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ duration: 0.3, ease: [0.19, 1, 0.22, 1] }}
              className="bg-white rounded-2xl shadow-2xl w-full max-w-[460px] p-8 pointer-events-auto relative"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Close button */}
              <button
                onClick={onClose}
                className="absolute top-6 right-6 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                  <path d="M18 6L6 18M6 6l12 12" />
                </svg>
              </button>

              {/* Header */}
              <div className="text-center mb-8">
                <h2 className="text-3xl mb-2" style={{ color: '#0066CC' }}>
                  Criar Conta
                </h2>
                <p className="text-gray-500 text-sm">Junte-se à comunidade Algarve Explorer</p>
              </div>

              {/* GitHub login button */}
              <motion.button
                type="button"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleGithubLogin}
                className="w-full py-3.5 rounded-xl border-2 border-gray-200 hover:border-gray-300 transition-all duration-300 flex items-center justify-center gap-3 mb-6 bg-white"
              >
                <Github size={20} />
                <span className="font-medium text-gray-700">Continuar com GitHub</span>
              </motion.button>

              {/* Divider */}
              <div className="flex items-center gap-4 mb-6">
                <div className="flex-1 h-px bg-gray-200" />
                <span className="text-sm text-gray-400">ou</span>
                <div className="flex-1 h-px bg-gray-200" />
              </div>

              {/* Registration form */}
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Email field */}
                <div>
                  <label htmlFor="register-email" className="block text-sm mb-2 text-gray-700">
                    Email
                  </label>
                  <input
                    type="email"
                    id="register-email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    onFocus={() => setFocusedField('email')}
                    onBlur={() => setFocusedField(null)}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl outline-none transition-all duration-300 bg-white"
                    style={{
                      borderColor: focusedField === 'email' ? '#0066CC' : undefined,
                      boxShadow: focusedField === 'email' ? '0 0 0 4px rgba(0, 102, 204, 0.08)' : undefined,
                    }}
                    placeholder="seu@email.com"
                    required
                  />
                </div>

                {/* Password field */}
                <div>
                  <label htmlFor="register-password" className="block text-sm mb-2 text-gray-700">
                    Palavra-passe
                  </label>
                  <input
                    type="password"
                    id="register-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    onFocus={() => setFocusedField('password')}
                    onBlur={() => setFocusedField(null)}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl outline-none transition-all duration-300 bg-white"
                    style={{
                      borderColor: focusedField === 'password' ? '#0066CC' : undefined,
                      boxShadow: focusedField === 'password' ? '0 0 0 4px rgba(0, 102, 204, 0.08)' : undefined,
                    }}
                    placeholder="Mínimo 8 caracteres"
                    required
                    minLength={8}
                  />
                </div>

                {/* Confirm password field */}
                <div>
                  <label htmlFor="confirm-password" className="block text-sm mb-2 text-gray-700">
                    Confirmar palavra-passe
                  </label>
                  <input
                    type="password"
                    id="confirm-password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    onFocus={() => setFocusedField('confirm')}
                    onBlur={() => setFocusedField(null)}
                    className="w-full px-4 py-3 border-2 border-gray-200 rounded-xl outline-none transition-all duration-300 bg-white"
                    style={{
                      borderColor: focusedField === 'confirm' ? '#0066CC' : undefined,
                      boxShadow: focusedField === 'confirm' ? '0 0 0 4px rgba(0, 102, 204, 0.08)' : undefined,
                    }}
                    placeholder="Confirme a palavra-passe"
                    required
                    minLength={8}
                  />
                </div>

                {/* Submit button */}
                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full py-3.5 rounded-xl text-white font-medium tracking-wide transition-all duration-300 shadow-lg relative overflow-hidden group mt-6"
                  style={{
                    background: 'linear-gradient(135deg, #0066CC 0%, #0052A3 100%)',
                    boxShadow: '0 10px 30px -10px rgba(0, 102, 204, 0.4)',
                  }}
                >
                  <span className="relative z-10">Criar Conta</span>
                  <motion.div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity duration-300" />
                </motion.button>
              </form>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}
